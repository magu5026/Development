data.raw['solar-panel']['solar-panel'].production = "240kW"
data.raw['accumulator']['accumulator'].energy_source.buffer_capacity = "20MJ"
data.raw['accumulator']['accumulator'].energy_source.input_flow_limit = "1200kW"
data.raw['accumulator']['accumulator'].energy_source.output_flow_limit = "1200kW"